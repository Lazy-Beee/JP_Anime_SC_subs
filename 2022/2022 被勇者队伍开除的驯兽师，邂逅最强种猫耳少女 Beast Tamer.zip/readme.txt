Src：
https://bbs.acgrip.com/forum.php?mod=redirect&goto=findpost&ptid=10361&pid=97987
https://animesongz.com/titles/5798

Mod:
各种字体样式
OPED日语歌词
"" → 「」

Font:
FOT-スーラ Pro B <FOT-Seurat Pro B>
方正兰亭圆_GBK_粗 <FZLanTingYuan-B-GBK>
方正隶变_GBK <FZLiBian-S02>
方正喵呜_GBK <FZMiaoWu-GBK>
思源黑体 Bold

Updates:
2024/01/09 标题对帧并添加blur