Source:
哔哩哔哩港澳台+繁化姬（https://bbs.acgrip.com/thread-11365-1-1.html）
https://animesongz.com/titles/5677

Mod:
各类字体样式
优化屏字效果
增补日语歌词
修正时轴错误

Fonts:
Chill Round Gothic Bold
ヒラギノ丸ゴ Std W6 <Hiragino Maru Gothic Std W6>
ヒラギノ丸ゴ Std W8 <Hiragino Maru Gothic Std W8>
方正粗圆_GBK <FZCuYuan-M03>
方正剪纸_GBK <FZJianZhi-M23>
方正经黑手写简体 <FZJingHeiShouXieS-R-GB>
方正兰亭粗黑_GBK <FZLanTingHei-B-GBK>
方正兰亭细黑_GBK <FZLanTingHei-L-GBK>
方正兰亭圆_GBK <FZLanTingYuan-R-GBK>
方正兰亭圆_GBK_粗 <FZLanTingYuan-B-GBK>
方正兰亭圆_GBK_大 <FZLanTingYuan-EB-GBK>
方正兰亭圆_GBK_细 <FZLanTingYuan-L-GBK>
方正兰亭圆_GBK_中 <FZLanTingYuan-DB-GBK>
方正兰亭中黑_GBK <FZLanTingHei-DB-GBK>
方正手迹-艾玛棒棒体 <FZSJ-AMBBJW>
方正手迹-爆米花体 <FZSJ-BMHJW>
方正手迹-少年时代体 <FZSJ-SNSDJW>
方正手迹-童趣体 <FZSJ-TQJW>
华康POP3体W12 <DFPOP3W12-GB>

Note：这该死的(副)标题必须使用「WrapStyle: 2」也就是不自动换行才能正常显示！