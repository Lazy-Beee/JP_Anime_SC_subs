Src：https://bbs.acgrip.com/forum.php?mod=viewthread&tid=9595

Mod：
正文、OP、ED样式

EP01,02 屏字

Font：
FOT-マティス ProN DB <FOT-Matisse ProN DB>
方正中雅宋_GBK <FZYaSong-DB-GBK>
思源黑体 Medium <Source Han Sans SC Medium>
思源宋体 Heavy <Source Han Serif SC Heavy>

https://wwbu.lanzouq.com/iamKU19t8vxc
密码:199s
