VCB-S修整期间作品

ALL


EP01 
Dialogue: 0,0:15:50.64,0:15:55.02,Default,,0,0,0,,{\fs45\pos(696,980)\b1\fsp24}····
↓
Dialogue: 0,0:15:50.64,0:15:55.02,Default,,0,0,0,,{\fs45\pos(683,985)\b1\fsp24}····

EP06
Dialogue: 0,0:17:20.23,0:17:23.36,Default,,0,0,0,,{\fs42\pos(1294,974)}Saya
↓
Dialogue: 0,0:17:20.23,0:17:23.36,Default,,0,0,0,,{\fs42\pos(1310,988)}Saya