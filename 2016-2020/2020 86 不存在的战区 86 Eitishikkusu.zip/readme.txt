Src：
https://bbs.acgrip.com/forum.php?mod=redirect&goto=findpost&ptid=9296&pid=96303&fromuid=41888

Mod：
EP02 0:03:46.62 去除部分屏字 
     0:07:30.80 插入曲【THE ANSWER】
EP05 0:19:10.25 black ship → black sheep
EP08 0:16:55.73 插入曲【Two Worlds Apart】
EP16 0:19:08.26 消散他们 → 消散的他们
EP21 0:14:56.79 插入曲【THE ANSWER】
EP22 0:11:18.05 插入曲【Voices of the Chord】

Ref: 
1. 86 - Eighty Six - Wiki
- https://86-eighty-six.fandom.com/wiki/Disc_1_Track_1
- https://86-eighty-six.fandom.com/wiki/Disc_1_Track_5
- https://86-eighty-six.fandom.com/wiki/Disc_2_Track_1
2. DeepL