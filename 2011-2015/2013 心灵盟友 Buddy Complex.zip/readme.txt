Src:
https://bbs.acgrip.com/forum.php?mod=redirect&goto=findpost&ptid=1972&pid=95507

Mod:
更换ED、屏字字体
微调OP、ED、屏字样式
增加少量屏字

EP07
Dialogue: 0,0:12:50.05,0:12:52.65,Default,,0,0,0,,这次出击…不 是决定今后谁和谁做搭档
↓ 时轴修正
Dialogue: 0,0:12:47.94,0:12:52.65,Default,,0,0,0,,这次出击…不 是决定今后谁和谁做搭档

EP08
Dialogue: 0,0:07:20.50,0:07:21.63,Default,,0,0,0,,我丑化说在前头
↓ 化 → 话
Dialogue: 0,0:07:20.50,0:07:21.63,Default,,0,0,0,,我丑话说在前头

EP14
多处 Necttar → Nectar

Font：
A-OTF リュウミン Pro H-KL <A-OTF Ryumin Pro H-KL>
FOT-ユトリロ Pro DB <FOT-Utrillo Pro DB>
霞鹜文楷 <LXGW WenKai>
方正粗雅宋_GBK <FZYaSong-B-GBK>
方正黑体_GBK <FZHei-B01>
方正中等线_GBK <FZZhongDengXian-Z07>
方正中雅宋_GBK <FZYaSong-DB-GBK>
微软雅黑 <Microsoft YaHei>
