Src:
https://bbs.acgrip.com/forum.php?mod=redirect&goto=findpost&ptid=10918&pid=102418
https://animesongz.com/titles/5934

Mod:
OPED-增加日语歌词，调整样式
标题-对帧，调整样式
清楚无效样式

Font:
EPSON 太明朝体Ｂ
方正兰亭黑_GBK <FZLanTingHei-R-GBK>
方正兰亭中黑_GBK <FZLanTingHei-DB-GBK>
方正兰亭准黑_GBK <FZLanTingHei-M-GBK>
方正小标宋_GBK <FZXiaoBiaoSong-B05>
霞鹜文楷等宽 Bold <LXGW WenKai Mono Bold>


