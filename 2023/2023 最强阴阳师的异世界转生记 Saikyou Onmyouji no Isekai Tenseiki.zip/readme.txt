Src:
- https://bbs.acgrip.com/forum.php?mod=viewthread&tid=10768&page=1#pid101374
    DLKS140@Anime字幕论坛：
    修改自B站港澳台。
    具体修改包括：调整字体、大小、位置重叠；分离OP/ED；修正部分分集中的缺字、错别字，参考漫画原作统一人物、地点名称和称谓，修改原字幕中部分不通顺的语句，增加注释等。
    仅包含简体，时轴未精调，望感兴趣的大佬能进一步改进本字幕，谢谢！
    包含字体：方正兰亭圆_GBK_、华康手札体W7-、方正准雅宋、方正准圆
- https://animesongz.com/titles/5881
- https://chat.openai.com/

Mod:
- 整理、调整字体样式
- OPED重翻，增加日语歌词，重制样式
- 标点微调
- 增补EP03 插入曲「月夜のタクト」

Fonts:
方正剪纸_GBK <FZJianZhi-M23>
方正兰亭圆_GBK_中 <FZLanTingYuan-DB-GBK>
方正中雅宋_GBK <FZYaSong-DB-GBK>
方正准雅宋_GBK <FZYaSong-M-GBK>
方正准圆_GBK <FZZhunYuan-M02>
华康手札体W7-A <DFHannotateW7-A>
